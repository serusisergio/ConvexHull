#include "common.h"

int WINDOW_MANAGER_ID = -1;
int DCEL_MANAGER_ID = -1;
int CONVEX_HULL_MANAGER_ID = -1;
int DCEL_CH_MANAGER_ID = -1;
